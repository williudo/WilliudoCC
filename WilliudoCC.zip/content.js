let capturing = false;
let captions = [];

const captureCaptions = (captionText) => {
    if (capturing) {
        captions.push(captionText);
    }
};

const observeCaptions = () => {
    const targetNode = document.querySelector('.VbkSUe'); // Selector for captions container
    if (targetNode) {
        const config = { childList: true, subtree: true };
        const callback = (mutationsList) => {
            for (let mutation of mutationsList) {
                if (mutation.type === 'childList') {
                    mutation.addedNodes.forEach(node => {
                        if (node.nodeType === 1) {
                            const captionText = node.innerText;
                            captureCaptions(captionText);
                        }
                    });
                }
            }
        };
        const observer = new MutationObserver(callback);
        observer.observe(targetNode, config);
    }
};

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.command === 'start') {
        capturing = true;
        observeCaptions();
    } else if (request.command === 'pause') {
        capturing = false;
    } else if (request.command === 'stop') {
        capturing = false;
        chrome.runtime.sendMessage({ type: 'download', data: captions.join('\n') });
        captions = [];
    }
});
