chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.type === 'download') {
        const blob = new Blob([request.data], { type: 'text/plain' });
        const url = URL.createObjectURL(blob);
        chrome.downloads.download({
            url: url,
            filename: 'captions.txt'
        });
    }
});
